import { LucideIcon } from 'lucide-react';

export type ThemeMode = 'light' | 'dark' | 'high-contrast';

export interface Quiz {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface Slide {
  title: string;
  description: string;
  icon: LucideIcon;
}

export interface NextStep {
  label: string;
  action: string; // Description displayed to user
  icon: LucideIcon;
  url?: string; // External link URL (optional)
}

export interface Tutorial {
  id: string;
  title: string;
  shortDescription: string;
  fullContent: string;
  icon: LucideIcon;
  tips: string[];
  quiz: Quiz;
  slides: Slide[];
  nextSteps?: NextStep[];
}

export interface ThemeConfig {
  theme: ThemeMode;
  fontScale: number; // 1, 1.25, 1.5
}