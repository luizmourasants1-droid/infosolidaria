import React, { useState, useRef } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import TutorialList from './components/TutorialList';
import Modal from './components/Modal';
import Footer from './components/Footer';
import GlossarySection from './components/GlossarySection';
import { Tutorial, ThemeMode } from './types';

const App: React.FC = () => {
  // State for Accessibility Settings
  // 'light' = Standard, 'dark' = Modern Dark Mode, 'high-contrast' = Yellow/Black
  const [theme, setTheme] = useState<ThemeMode>('light');
  const [fontScale, setFontScale] = useState<number>(1); // 1 = 100%, 1.25 = 125%, 1.5 = 150%

  // State for Modal and Focus Management
  const [selectedTutorial, setSelectedTutorial] = useState<Tutorial | null>(null);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  // Ref to store the button that triggered the modal so we can return focus to it
  const lastFocusedElementRef = useRef<HTMLElement | null>(null);

  // Handlers
  const handleThemeChange = (newTheme: ThemeMode) => {
    setTheme(newTheme);
  };
  
  const increaseFont = () => {
    setFontScale(prev => Math.min(prev + 0.25, 1.5));
  };
  
  const decreaseFont = () => {
    setFontScale(prev => Math.max(prev - 0.25, 1));
  };

  const openTutorial = (tutorial: Tutorial, event?: React.MouseEvent | React.KeyboardEvent) => {
    // Store the current focused element (the card) before opening modal
    if (document.activeElement instanceof HTMLElement) {
      lastFocusedElementRef.current = document.activeElement;
    }
    
    setSelectedTutorial(tutorial);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    // Add small delay to clear data after animation finishes
    setTimeout(() => {
      setSelectedTutorial(null);
      // Accessibility: Return focus to the card that opened the modal
      if (lastFocusedElementRef.current) {
        lastFocusedElementRef.current.focus();
      }
    }, 200);
  };

  // Base styles based on Theme Mode
  const getAppBackground = () => {
    switch (theme) {
      case 'high-contrast': return 'bg-black min-h-screen text-yellow-400';
      case 'dark': return 'bg-gray-900 min-h-screen text-gray-100'; // Anthracite background
      default: return 'bg-white min-h-screen text-slate-900';
    }
  };

  const getSkipLinkStyles = () => {
    switch (theme) {
      case 'high-contrast': return 'bg-yellow-400 text-black';
      case 'dark': return 'bg-teal-500 text-white';
      default: return 'bg-teal-700 text-white';
    }
  };

  return (
    <div 
      className={`transition-colors duration-300 font-sans ${getAppBackground()}`}
      style={{ fontSize: `${fontScale}rem` }}
    >
      {/* WCAG 2.4.1: Skip to Content Link */}
      <a 
        href="#main-content" 
        className={`fixed top-0 left-0 p-3 -translate-y-full focus:translate-y-0 z-[100] transition-transform font-bold ${getSkipLinkStyles()}`}
      >
        Pular para o conteúdo principal
      </a>

      <Header 
        theme={theme}
        fontScale={fontScale}
        setTheme={handleThemeChange}
        increaseFont={increaseFont}
        decreaseFont={decreaseFont}
      />

      <Hero theme={theme} />

      <TutorialList 
        theme={theme} 
        onSelectTutorial={openTutorial} 
      />

      <GlossarySection theme={theme} />

      <Footer theme={theme} />

      <Modal 
        isOpen={isModalOpen}
        onClose={closeModal}
        tutorial={selectedTutorial}
        theme={theme}
      />
    </div>
  );
};

export default App;