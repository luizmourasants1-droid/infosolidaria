import { ShieldCheck, Lock, AlertTriangle, Eye, Smartphone, CreditCard, MailWarning, Users, KeyRound, UserX, Search, Calendar, MousePointer2, AlertOctagon, Link2, Download, ShieldAlert, Wifi, Globe, Briefcase, HeartHandshake, Siren, Settings, ExternalLink, XCircle } from 'lucide-react';
import { Tutorial } from './types';

// NOTE: In a real production app, ensure all external links are vetted.
// These links point to official Brazilian government/safety bodies (CERT.br, BCB) or major platform FAQs.

export const TUTORIALS: Tutorial[] = [
  {
    id: 'safe-browsing',
    title: 'Navegação Segura e Wi-Fi',
    shortDescription: 'Primeiros passos para usar a internet sem riscos: Cadeados, Wi-Fi de rua e Janelas chatas.',
    icon: Globe,
    fullContent: 'Navegar na internet é como andar na rua: precisamos saber onde pisar. Sites seguros protegem seus dados, e redes Wi-Fi públicas exigem cuidado redobrado.',
    tips: [
      'Procure sempre pelo cadeado 🔒 ao lado do endereço do site (HTTPS).',
      'Evite acessar banco ou digitar senhas usando o Wi-Fi grátis da praça ou rodoviária.',
      'Se aparecer uma janela (pop-up) dizendo que você ganhou um prêmio, feche no "X" imediatamente.',
      'Mantenha seu navegador (Chrome, Edge, Firefox) sempre atualizado.'
    ],
    slides: [
      {
        title: 'O Cadeado Importa',
        description: 'Sites seguros começam com "https://" e têm um cadeado na barra de endereço.',
        icon: Lock
      },
      {
        title: 'Cuidado com Wi-Fi Grátis',
        description: 'Em redes públicas (shopping, praça), qualquer um pode ver o que você envia. Use o 4G para coisas importantes.',
        icon: Wifi
      },
      {
        title: 'Feche Janelas Estranhas',
        description: 'Se uma janela pular na tela prometendo prêmios, não clique em "OK". Procure o "X" para fechar.',
        icon: XCircle
      }
    ],
    quiz: {
      question: 'Você está na praça de alimentação e precisa pagar uma conta pelo aplicativo do banco. O que é mais seguro?',
      options: [
        'Conectar no Wi-Fi "Shopping_Gratis_Sem_Senha" para economizar dados.',
        'Desligar o Wi-Fi e usar a internet do seu chip (4G/5G).',
        'Pedir a senha do Wi-Fi para um desconhecido.'
      ],
      correctIndex: 1,
      explanation: 'Redes Wi-Fi públicas, especialmente as sem senha, são fáceis de espionar. Para transações bancárias, a rede do seu celular (4G/5G) é muito mais segura.'
    },
    nextSteps: [
      { 
        label: 'Verificar Navegador', 
        action: 'Simulação: Atualizando o Google Chrome.', 
        icon: Download,
        url: 'https://support.google.com/chrome/answer/95414?hl=pt-BR&co=GENIE.Platform%3DDesktop'
      },
      { 
        label: 'Dicas de Wi-Fi', 
        action: 'Ler cartilha do CERT.br sobre Redes.', 
        icon: Wifi,
        url: 'https://cartilha.cert.br/fasciculos/redes-sem-fio/fasciculo-redes-sem-fio.pdf'
      }
    ]
  },
  {
    id: 'passwords',
    title: 'Senhas Fortes',
    shortDescription: 'Aprenda a criar senhas que ninguém consegue adivinhar.',
    icon: Lock,
    fullContent: 'Uma senha forte é como a chave da sua casa. Se ela for simples, qualquer um pode entrar. Não use datas de aniversário ou nomes de familiares.',
    tips: [
      'Misture letras maiúsculas, minúsculas e números.',
      'Use frases que só você entende, ex: "Gosto#De#Bolo#De#Fuba".',
      'Evite sequências como 123456 ou "senha".',
      'Tenha uma senha diferente para cada site importante.'
    ],
    slides: [
      {
        title: 'Evite o Óbvio',
        description: 'Nunca use "123456", seu nome ou sua data de nascimento.',
        icon: UserX
      },
      {
        title: 'Misture Tudo',
        description: 'Use letras MAIÚSCULAS, minúsculas, números (1, 2) e símbolos (!, #).',
        icon: KeyRound
      },
      {
        title: 'Frases Secretas',
        description: 'Crie uma frase longa que só você conhece. Ex: "O-Sol-Brilha-No-Sítio!".',
        icon: ShieldCheck
      }
    ],
    quiz: {
      question: 'Qual destas é a senha mais segura?',
      options: [
        'maria1960',
        '12345678',
        'EuAmoCafeComLeite!2024'
      ],
      correctIndex: 2,
      explanation: 'A opção 3 é a melhor pois é uma frase longa, mistura letras, e inclui um caractere especial (!).'
    },
    nextSteps: [
      { 
        label: 'Verificar se minha senha vazou', 
        action: 'Ir para site Have I Been Pwned (Seguro)', 
        icon: Search,
        url: 'https://haveibeenpwned.com/'
      },
      { 
        label: 'Cartilha de Senhas', 
        action: 'Ler guia oficial do CERT.br', 
        icon: Lock,
        url: 'https://cartilha.cert.br/senhas/' 
      }
    ]
  },
  {
    id: 'fake-news',
    title: 'Notícias Falsas',
    shortDescription: 'Como saber se uma notícia do WhatsApp é verdade ou mentira.',
    icon: Eye,
    fullContent: 'As notícias falsas (Fake News) são criadas para causar pânico ou enganar as pessoas. Antes de repassar uma mensagem, verifique se ela é real.',
    tips: [
      'Desconfie de títulos muito alarmantes ou com erros de português.',
      'Pesquise o título da notícia no Google para ver se jornais sérios estão falando sobre isso.',
      'Olhe a data da notícia. Às vezes é algo verdadeiro, mas de 10 anos atrás.',
      'Se a mensagem diz "Repasse para 10 pessoas", geralmente é golpe ou mentira.'
    ],
    slides: [
      {
        title: 'Títulos Alarmantes',
        description: 'Desconfie de mensagens que dizem "URGENTE", "ATENÇÃO" ou "REPASSE AGORA".',
        icon: AlertTriangle
      },
      {
        title: 'Verifique a Fonte',
        description: 'Pesquise no Google para ver se jornais conhecidos estão falando sobre isso.',
        icon: Search
      },
      {
        title: 'Olhe a Data',
        description: 'Muitas vezes a notícia é verdadeira, mas aconteceu há 5 anos atrás.',
        icon: Calendar
      }
    ],
    quiz: {
      question: 'Você recebeu uma mensagem dizendo "Cura milagrosa descoberta! Repasse agora!". O que fazer?',
      options: [
        'Repassar para a família toda para ajudar.',
        'Ignorar, pesquisar no Google e não repassar.',
        'Clicar no link imediatamente.'
      ],
      correctIndex: 1,
      explanation: 'Sempre pesquise antes de compartilhar. Promessas milagrosas e pedidos de compartilhamento urgente geralmente são falsos.'
    },
    nextSteps: [
      { 
        label: 'Consultar Fato ou Fake', 
        action: 'Acessar portal G1 Fato ou Fake', 
        icon: Search,
        url: 'https://g1.globo.com/fato-ou-fake/'
      },
      { 
        label: 'Agência Lupa', 
        action: 'Verificar notícias na Agência Lupa', 
        icon: Globe,
        url: 'https://lupa.uol.com.br/'
      }
    ]
  },
  {
    id: 'phishing',
    title: 'Links Suspeitos',
    shortDescription: 'Cuidado com mensagens SMS e promoções falsas.',
    icon: AlertTriangle,
    fullContent: 'O "Phishing" é uma pescaria digital. O bandido joga uma isca (uma mensagem falsa de banco ou promoção) esperando você "morder" clicando no link.',
    tips: [
      'Bancos NUNCA pedem senha por e-mail ou SMS.',
      'Não clique em links de promoções que parecem boas demais para ser verdade.',
      'Na dúvida, ligue para a empresa ou seu gerente.',
      'Se o link for encurtado ou estranho, não clique.'
    ],
    slides: [
      {
        title: 'Não Clique',
        description: 'Recebeu um link estranho por SMS ou Zap? Não clique nele.',
        icon: MousePointer2
      },
      {
        title: 'Ofertas Milagrosas',
        description: 'TV de 50 polegadas por R$ 100,00? É golpe na certa.',
        icon: AlertOctagon
      },
      {
        title: 'Verifique o Link',
        description: 'Sites seguros começam com "https" e têm um cadeado ao lado do endereço.',
        icon: Link2
      }
    ],
    quiz: {
      question: 'Você recebeu um SMS: "Sua conta foi bloqueada. Clique aqui para liberar". O que fazer?',
      options: [
        'Clicar no link para resolver logo.',
        'Responder o SMS perguntando o motivo.',
        'Não clicar e abrir o aplicativo oficial do banco para verificar.'
      ],
      correctIndex: 2,
      explanation: 'Nunca clique em links de SMS de alerta. Sempre verifique diretamente no aplicativo oficial ou ligue para o banco.'
    },
    nextSteps: [
      { 
        label: 'Testar Link Seguro', 
        action: 'Ferramenta Google Safe Browsing', 
        icon: Search,
        url: 'https://transparencyreport.google.com/safe-browsing/search'
      },
      { 
        label: 'Site Internet Segura', 
        action: 'Guia do Governo Brasileiro', 
        icon: ExternalLink,
        url: 'https://internetsegura.br/'
      }
    ]
  },
  {
    id: 'email-fraud',
    title: 'E-mails Fraudulentos',
    shortDescription: 'Identifique remetentes falsos e anexos perigosos na sua caixa de entrada.',
    icon: MailWarning,
    fullContent: 'Criminosos enviam e-mails fingindo ser empresas conhecidas (Correios, Netflix, Receita Federal) para roubar dados ou instalar vírus.',
    tips: [
      'Verifique o remetente: "netflix@promo-filmes-gratis.com" NÃO é a Netflix.',
      'Cuidado com anexos (arquivos PDF, ZIP) que você não pediu. Não baixe.',
      'Observe erros de ortografia e linguagem de urgência ("Sua conta será cancelada hoje!").',
      'Passe o mouse sobre o botão (sem clicar) para ver o endereço real do link.'
    ],
    slides: [
      {
        title: 'Olhe o Remetente',
        description: 'Confira se o e-mail é oficial. Empresas grandes não usam @gmail ou @hotmail.',
        icon: UserX
      },
      {
        title: 'Cuidado com Anexos',
        description: 'Não baixe arquivos PDF ou ZIP se você não sabe quem mandou.',
        icon: Download
      },
      {
        title: 'Senso de Urgência',
        description: 'E-mails dizendo "Sua conta será cancelada HOJE" geralmente são falsos.',
        icon: ShieldAlert
      }
    ],
    quiz: {
      question: 'Como verificar se um e-mail dos "Correios" é verdadeiro?',
      options: [
        'Verificar se o remetente termina exatamente com "@correios.com.br".',
        'Acreditar, pois tem o logotipo dos Correios.',
        'Clicar no botão "Rastrear Encomenda" imediatamente.'
      ],
      correctIndex: 0,
      explanation: 'O endereço do remetente é a pista mais importante. Golpistas usam logotipos reais, mas o endereço de e-mail costuma ser estranho.'
    },
    nextSteps: [
      { 
        label: 'Como bloquear Spam', 
        action: 'Ajuda do Gmail (Google)', 
        icon: MailWarning,
        url: 'https://support.google.com/mail/answer/8151?hl=pt-BR'
      },
      { 
        label: 'Denunciar Fraude', 
        action: 'Site SaferNet Brasil', 
        icon: Siren,
        url: 'https://new.safernet.org.br/denuncie'
      }
    ]
  },
  {
    id: 'social-media',
    title: 'Redes Sociais',
    shortDescription: 'Protegendo seu Facebook, Instagram e outras redes.',
    icon: Users,
    fullContent: 'As redes sociais são ótimas para conectar, mas expõem nossa vida. Golpistas usam informações públicas para tentar adivinhar senhas ou enganar familiares.',
    tips: [
      'Deixe seu perfil como "Privado" para que apenas amigos vejam suas fotos.',
      'Não aceite pedidos de amizade de pessoas que você não conhece pessoalmente.',
      'Evite postar fotos que mostrem o endereço da sua casa ou placa do carro.',
      'Não faça testes online do tipo "Com qual famoso você parece?", eles roubam seus dados.'
    ],
    slides: [
      {
        title: 'Perfil Privado',
        description: 'Configure suas redes para que só amigos vejam suas fotos.',
        icon: Lock
      },
      {
        title: 'Não Aceite Estranhos',
        description: 'Não aceite amizade de quem você não conhece na vida real.',
        icon: UserX
      },
      {
        title: 'Testes Online',
        description: 'Evite testes como "Qual celebridade você parece?". Eles coletam seus dados.',
        icon: MousePointer2
      }
    ],
    quiz: {
      question: 'Um desconhecido pediu amizade e diz ser amigo de um primo distante. O que fazer?',
      options: [
        'Aceitar para ser educado.',
        'Aceitar e perguntar quem ele é.',
        'Não aceitar e, se quiser, perguntar ao seu primo se ele conhece a pessoa.'
      ],
      correctIndex: 2,
      explanation: 'É mais seguro não aceitar desconhecidos. Perfis falsos são usados para espionar sua rotina e aplicar golpes.'
    },
    nextSteps: [
      { 
        label: 'Privacidade no Facebook', 
        action: 'Configurações de Privacidade', 
        icon: Settings,
        url: 'https://www.facebook.com/help/325807937506242'
      },
      { 
        label: 'Dicas Instagram', 
        action: 'Central de Segurança Instagram', 
        icon: Users,
        url: 'https://about.instagram.com/pt-br/safety'
      }
    ]
  },
  {
    id: 'whatsapp',
    title: 'Golpes no WhatsApp',
    shortDescription: 'Proteja sua conta e não caia no pedido de dinheiro.',
    icon: Smartphone,
    fullContent: 'Muitos golpistas clonam o WhatsApp ou usam uma foto sua para pedir dinheiro aos seus contatos. Proteja-se ativando a segurança.',
    tips: [
      'Ative a "Confirmação em Duas Etapas" nas configurações do WhatsApp.',
      'Nunca compartilhe o código de 6 dígitos que chega por SMS com ninguém.',
      'Se um parente pedir dinheiro por mensagem, ligue para ele antes de transferir.',
      'Oculte sua foto de perfil para quem não é seu contato.'
    ],
    slides: [
      {
        title: 'Dupla Proteção',
        description: 'Ative a "Confirmação em Duas Etapas" nas configurações.',
        icon: ShieldCheck
      },
      {
        title: 'Código Secreto',
        description: 'NUNCA compartilhe o código de 6 dígitos que chega por SMS.',
        icon: KeyRound
      },
      {
        title: 'Pedido de Dinheiro',
        description: 'Se alguém pedir dinheiro pelo Zap, ligue para a pessoa para confirmar a voz.',
        icon: Smartphone
      }
    ],
    quiz: {
      question: 'Alguém te ligou pedindo um código que chegou por SMS para confirmar um anúncio. Você:',
      options: [
        'Passa o código.',
        'Desliga o telefone e não passa o código.',
        'Tira um print e manda.'
      ],
      correctIndex: 1,
      explanation: 'O código de 6 dígitos é a chave do seu WhatsApp. Nunca compartilhe ele com ninguém, sob nenhuma hipótese.'
    },
    nextSteps: [
      { 
        label: 'Ativar 2 Etapas (Android/iPhone)', 
        action: 'Guia Oficial do WhatsApp', 
        icon: ShieldCheck,
        url: 'https://faq.whatsapp.com/1267263720630985/?locale=pt_BR'
      },
      { 
        label: 'Central de Segurança', 
        action: 'Dicas de Segurança WhatsApp', 
        icon: Siren,
        url: 'https://www.whatsapp.com/security?lang=pt_br'
      }
    ]
  },
  {
    id: 'banking',
    title: 'Banco e Pix',
    shortDescription: 'Segurança na hora de mexer no dinheiro pelo celular.',
    icon: CreditCard,
    fullContent: 'Usar o banco pelo celular é prático, mas exige atenção redobrada. Mantenha seus dados seguros e não faça transferências na pressa.',
    tips: [
      'Não use o aplicativo do banco em Wi-Fi público (restaurantes, praças).',
      'Confira sempre o nome de quem vai receber o PIX antes de confirmar.',
      'Diminua o limite de transferência do seu banco para evitar grandes perdas.',
      'Se perder o celular, avise o banco imediatamente.'
    ],
    slides: [
      {
        title: 'Wi-Fi Público',
        description: 'Evite usar o banco no Wi-Fi da praça ou shopping. Use o 4G/5G.',
        icon: Wifi
      },
      {
        title: 'Confira o PIX',
        description: 'Leia o nome de quem vai receber o dinheiro antes de digitar a senha.',
        icon: Eye
      },
      {
        title: 'Ajuste o Limite',
        description: 'Deixe o limite de transferência baixo para o dia a dia.',
        icon: CreditCard
      }
    ],
    quiz: {
      question: 'Ao fazer um PIX, o que é mais importante conferir?',
      options: [
        'Se o valor está correto e o nome do recebedor bate com quem você quer pagar.',
        'Se a internet está rápida.',
        'Se o comprovante é bonito.'
      ],
      correctIndex: 0,
      explanation: 'Sempre confira os dados de quem recebe. Golpes do PIX geralmente usam contas de "laranjas" (pessoas falsas).'
    },
    nextSteps: [
      { 
        label: 'Tudo sobre Pix', 
        action: 'Página do Banco Central', 
        icon: ExternalLink,
        url: 'https://www.bcb.gov.br/estabilidadefinanceira/pix'
      },
      { 
        label: 'Dicas FEBRABAN', 
        action: 'Federação Brasileira de Bancos', 
        icon: ShieldAlert,
        url: 'https://antifraudes.febraban.org.br/'
      }
    ]
  },
  {
    id: 'protection',
    title: 'Antivírus Básico',
    shortDescription: 'Mantendo a saúde do seu computador e celular.',
    icon: ShieldCheck,
    fullContent: 'Assim como tomamos vacina, o computador precisa de proteção. Um bom antivírus ajuda a bloquear programas maliciosos.',
    tips: [
      'Mantenha o sistema do seu celular sempre atualizado.',
      'Use apenas a loja oficial (Play Store ou App Store) para baixar aplicativos.',
      'Não instale programas que desconhecidos enviam para você.',
      'Existem antivírus gratuitos e bons no mercado.'
    ],
    slides: [
      {
        title: 'Loja Oficial',
        description: 'Só baixe aplicativos pela Play Store ou Apple Store.',
        icon: Smartphone
      },
      {
        title: 'Atualize Sempre',
        description: 'Quando o celular pedir para atualizar, aceite. Isso corrige falhas.',
        icon: Download
      },
      {
        title: 'Navegação Segura',
        description: 'Não entre em sites estranhos para baixar filmes ou jogos grátis.',
        icon: Globe
      }
    ],
    quiz: {
      question: 'Onde é o lugar mais seguro para baixar aplicativos?',
      options: [
        'Em sites de busca aleatórios.',
        'Links enviados por grupos de WhatsApp.',
        'Lojas oficiais (Play Store no Android ou App Store no iPhone).'
      ],
      correctIndex: 2,
      explanation: 'Lojas oficiais verificam se os aplicativos têm vírus antes de disponibilizar para você.'
    },
    nextSteps: [
      { 
        label: 'Google Play Protect', 
        action: 'Entenda como funciona', 
        icon: ShieldCheck,
        url: 'https://support.google.com/googleplay/answer/2812853?hl=pt-BR'
      },
      { 
        label: 'Cartilha de Segurança', 
        action: 'CERT.br - Computadores', 
        icon: Download,
        url: 'https://cartilha.cert.br/computadores/'
      }
    ]
  },
  {
    id: 'fake-jobs',
    title: 'Falsas Vagas e Doações',
    shortDescription: 'Alerta sobre golpes de emprego e pedidos falsos de ajuda.',
    icon: Briefcase,
    fullContent: 'Golpistas se aproveitam da necessidade das pessoas. Eles oferecem empregos com salários altos e pouco esforço, ou pedem doações para causas que não existem.',
    tips: [
      'NUNCA pague para conseguir um emprego. Se cobrarem por uniforme ou curso, é golpe.',
      'Desconfie de vagas "fáceis" com salário muito alto para trabalhar de casa.',
      'Em doações, verifique se a ONG existe e é séria. Visite o local se puder.',
      'Não envie fotos dos seus documentos pessoais antes de ter certeza que a empresa existe.'
    ],
    slides: [
      {
        title: 'Pagou = Golpe',
        description: 'Nenhuma empresa séria cobra dinheiro do candidato por uniforme ou exame.',
        icon: AlertTriangle
      },
      {
        title: 'Dinheiro Fácil?',
        description: 'Vagas de "ganhe R$ 500 por dia curtindo fotos" são pirâmides ou golpes.',
        icon: AlertOctagon
      },
      {
        title: 'Doação Segura',
        description: 'Antes de doar, peça o CNPJ da instituição e pesquise na internet.',
        icon: HeartHandshake
      }
    ],
    quiz: {
      question: 'Uma vaga de emprego pede R$ 50,00 para "reservar sua farda". O que você faz?',
      options: [
        'Paga logo para garantir a vaga.',
        'Não paga e denuncia a vaga, pois emprego não deve cobrar do trabalhador.',
        'Pede um desconto.'
      ],
      correctIndex: 1,
      explanation: 'É ilegal cobrar por vagas de emprego ou material de trabalho antes da contratação. Isso é um sinal claro de golpe.'
    },
    nextSteps: [
      { 
        label: 'Denunciar no MPT', 
        action: 'Ministério Público do Trabalho', 
        icon: Siren,
        url: 'https://mpt.mp.br/pgt/denuncias'
      },
      { 
        label: 'Consulta CNPJ', 
        action: 'Site da Receita Federal', 
        icon: Search,
        url: 'https://solucoes.receita.fazenda.gov.br/Servicos/cnpjreva/cnpjreva_solicitacao.asp'
      }
    ]
  }
];