import React from 'react';
import { Shield, Sun, Moon, Type, Minus, Plus, Eye } from 'lucide-react';
import { ThemeMode } from '../types';

interface HeaderProps {
  theme: ThemeMode;
  fontScale: number;
  setTheme: (mode: ThemeMode) => void;
  increaseFont: () => void;
  decreaseFont: () => void;
}

const Header: React.FC<HeaderProps> = ({ 
  theme, 
  fontScale, 
  setTheme, 
  increaseFont, 
  decreaseFont 
}) => {
  
  // Style Logic
  const getHeaderStyles = () => {
    switch (theme) {
      case 'high-contrast': return 'bg-yellow-400 text-black border-b-4 border-black';
      case 'dark': return 'bg-gray-900 text-gray-100 border-b border-gray-800 shadow-teal-900/20'; // Dark Mode
      default: return 'bg-teal-700 text-white shadow-lg'; // Light Mode
    }
  };
  
  // Button Base Styles
  const getButtonStyles = (isActive: boolean = false) => {
    const base = "p-2 rounded-lg font-bold flex items-center gap-2 border-2 focus:ring-4 focus:outline-none transition-transform active:scale-95";
    
    if (theme === 'high-contrast') {
      return `${base} border-black bg-black text-yellow-400 hover:bg-gray-800 focus:ring-black`;
    }
    
    if (theme === 'dark') {
      return isActive 
        ? `${base} border-teal-400 bg-teal-500/20 text-teal-300 focus:ring-teal-400`
        : `${base} border-gray-700 bg-gray-800 text-gray-300 hover:border-teal-500 hover:text-teal-400 focus:ring-teal-400`;
    }

    // Light Mode
    return `${base} border-white/30 bg-teal-800 text-white hover:bg-teal-600 focus:ring-white`;
  };

  return (
    <header className={`${getHeaderStyles()} p-4 sticky top-0 z-50 transition-colors duration-300`}>
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
        
        {/* Logo Area */}
        <div className="flex items-center gap-3">
          <Shield size={48} className={theme === 'high-contrast' ? 'text-black' : (theme === 'dark' ? 'text-teal-400' : 'text-white')} />
          <div>
            <h1 className="text-3xl font-extrabold tracking-tight">InfoSolidária</h1>
            <p className={`text-sm ${theme === 'high-contrast' ? 'font-bold' : 'opacity-90'}`}>
              Segurança digital para todos
            </p>
          </div>
        </div>

        {/* Accessibility Controls */}
        <div className={`flex flex-wrap justify-center gap-3 p-2 rounded-xl ${theme === 'dark' ? 'bg-gray-800/50' : 'bg-white/10'}`} role="group" aria-label="Ferramentas de Acessibilidade">
          
          {/* Light Mode Button */}
          <button 
            onClick={() => setTheme('light')}
            className={getButtonStyles(theme === 'light')}
            aria-label="Ativar Modo Claro"
            title="Modo Claro"
          >
            <Sun size={20} />
            <span className="sr-only sm:not-sr-only text-sm">Claro</span>
          </button>

           {/* Dark Mode Button */}
           <button 
            onClick={() => setTheme('dark')}
            className={getButtonStyles(theme === 'dark')}
            aria-label="Ativar Modo Escuro"
            title="Modo Escuro"
          >
            <Moon size={20} />
            <span className="sr-only sm:not-sr-only text-sm">Escuro</span>
          </button>

          {/* High Contrast Button */}
          <button 
            onClick={() => setTheme('high-contrast')}
            className={getButtonStyles(theme === 'high-contrast')}
            aria-label="Ativar Contraste Extremo"
            title="Contraste Extremo"
          >
            <Eye size={20} />
            <span className="sr-only sm:not-sr-only text-sm">Contraste</span>
          </button>

          {/* Font Controls */}
          <div className="flex gap-1 ml-2 border-l pl-3 border-white/20" role="group" aria-label="Tamanho da fonte">
            <button 
              onClick={decreaseFont}
              className={getButtonStyles()}
              disabled={fontScale <= 1}
              aria-label="Diminuir texto"
              title="Diminuir Texto"
            >
              <Minus size={20} />
            </button>
            
            <button 
              onClick={increaseFont}
              className={getButtonStyles()}
              disabled={fontScale >= 1.5}
              aria-label="Aumentar texto"
              title="Aumentar Texto"
            >
              <Plus size={20} />
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};

export default Header;