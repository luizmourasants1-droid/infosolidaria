import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Circle, CircleDot } from 'lucide-react';
import { Slide, ThemeMode } from '../types';

interface SlideShowProps {
  slides: Slide[];
  theme: ThemeMode;
}

const SlideShow: React.FC<SlideShowProps> = ({ slides, theme }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const CurrentIcon = slides[currentIndex].icon;

  // STYLES
  const getContainerClass = () => {
    switch(theme) {
      case 'high-contrast': return 'bg-gray-900 border-2 border-yellow-400';
      case 'dark': return 'bg-gray-900 border border-gray-700';
      default: return 'bg-teal-50 border border-teal-200';
    }
  };

  const textClass = theme === 'high-contrast' ? 'text-yellow-400' : (theme === 'dark' ? 'text-gray-100' : 'text-teal-900');
  const descClass = theme === 'high-contrast' ? 'text-yellow-200' : (theme === 'dark' ? 'text-gray-300' : 'text-slate-600');

  const getButtonClass = () => {
    switch(theme) {
      case 'high-contrast': return 'bg-yellow-400 text-black hover:bg-white focus:ring-white';
      case 'dark': return 'bg-teal-600 text-white hover:bg-teal-500 focus:ring-teal-400';
      default: return 'bg-orange-500 text-white hover:bg-orange-600 focus:ring-orange-400';
    }
  };

  const iconColor = theme === 'high-contrast' ? 'text-yellow-400' : (theme === 'dark' ? 'text-teal-400' : 'text-teal-600');
  const getIconBg = () => {
    switch(theme) {
      case 'high-contrast': return 'bg-black border-2 border-yellow-400';
      case 'dark': return 'bg-gray-800 border border-gray-600';
      default: return 'bg-white shadow-md border border-teal-100';
    }
  };

  const getControlsBg = () => {
    switch(theme) {
      case 'high-contrast': return 'bg-black border-t border-yellow-400';
      case 'dark': return 'bg-gray-800 border-t border-gray-700';
      default: return 'bg-teal-100 border-t border-teal-200';
    }
  };

  return (
    <div 
      className={`rounded-xl overflow-hidden mb-8 ${getContainerClass()}`}
      role="region" 
      aria-label="Carrossel de dicas visuais"
    >
      <div className="p-6 md:p-8 flex flex-col items-center text-center min-h-[300px] justify-center relative">
        
        {/* Visual Content */}
        <div 
          className="animate-in fade-in slide-in-from-right-4 duration-300 w-full flex flex-col items-center"
          key={currentIndex} // Force re-render for animation
        >
          <div className={`p-4 rounded-full mb-4 ${getIconBg()}`}>
            <CurrentIcon size={64} className={iconColor} />
          </div>
          
          <h3 className={`text-2xl font-bold mb-3 ${textClass}`}>
            {slides[currentIndex].title}
          </h3>
          
          <p className={`text-xl max-w-md ${descClass}`}>
            {slides[currentIndex].description}
          </p>
        </div>

      </div>

      {/* Navigation Controls */}
      <div className={`p-4 flex items-center justify-between ${getControlsBg()}`}>
        
        <button
          onClick={prevSlide}
          className={`p-3 rounded-lg transition-colors focus:outline-none focus:ring-4 ${getButtonClass()}`}
          aria-label="Dica anterior"
        >
          <ChevronLeft size={28} />
        </button>

        {/* Progress Indicators */}
        <div className="flex gap-2" role="tablist" aria-label="Slides do tutorial">
          {slides.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={`focus:outline-none rounded-full p-1`}
              aria-label={`Ir para dica ${idx + 1}`}
              aria-selected={currentIndex === idx}
              role="tab"
            >
              {currentIndex === idx ? (
                <CircleDot 
                  size={20} 
                  className={theme === 'high-contrast' ? 'text-yellow-400 fill-yellow-400' : (theme === 'dark' ? 'text-teal-400 fill-teal-400' : 'text-orange-500 fill-orange-500')} 
                />
              ) : (
                <Circle 
                  size={16} 
                  className={theme === 'high-contrast' ? 'text-gray-600' : (theme === 'dark' ? 'text-gray-600' : 'text-slate-300')} 
                />
              )}
            </button>
          ))}
        </div>

        <button
          onClick={nextSlide}
          className={`p-3 rounded-lg transition-colors focus:outline-none focus:ring-4 ${getButtonClass()}`}
          aria-label="Próxima dica"
        >
          <ChevronRight size={28} />
        </button>

      </div>
    </div>
  );
};

export default SlideShow;