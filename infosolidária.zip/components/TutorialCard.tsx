import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Tutorial, ThemeMode } from '../types';

interface TutorialCardProps {
  tutorial: Tutorial;
  theme: ThemeMode;
  onClick: () => void;
}

const TutorialCard: React.FC<TutorialCardProps> = ({ tutorial, theme, onClick }) => {
  const CardIcon = tutorial.icon;

  // 1. Card Container Style
  const getCardStyle = () => {
    switch(theme) {
      case 'high-contrast': 
        return 'bg-black border-4 border-yellow-400 text-yellow-400 hover:bg-gray-900 focus:ring-white';
      case 'dark': 
        return 'bg-gray-800 border-2 border-gray-700 text-gray-100 hover:border-teal-500 hover:shadow-teal-900/20 hover:shadow-xl hover:-translate-y-1 focus:ring-teal-400 focus:border-teal-400';
      default: 
        return 'bg-white border-2 border-slate-200 text-slate-800 hover:border-teal-500 hover:shadow-xl hover:-translate-y-1 focus:ring-orange-400 focus:border-orange-500';
    }
  };

  // 2. Icon Style
  const getIconStyle = () => {
    switch(theme) {
      case 'high-contrast': return { color: 'text-yellow-400', bg: 'bg-gray-800' };
      case 'dark': return { color: 'text-teal-400', bg: 'bg-gray-900 border border-gray-700' };
      default: return { color: 'text-teal-600', bg: 'bg-teal-50' };
    }
  };

  // 3. Button Style
  const getButtonStyle = () => {
    switch(theme) {
      case 'high-contrast': return 'bg-yellow-400 text-black hover:bg-yellow-300';
      case 'dark': return 'bg-teal-600 text-white hover:bg-teal-500 shadow-md';
      default: return 'bg-orange-500 text-white hover:bg-orange-600 shadow-md';
    }
  };

  const iconStyles = getIconStyle();

  return (
    <article 
      className={`rounded-2xl p-6 transition-all duration-300 cursor-pointer flex flex-col h-full focus:outline-none focus:ring-4 ${getCardStyle()}`}
      onClick={onClick}
      role="button"
      tabIndex={0}
      aria-label={`Ler tutorial sobre ${tutorial.title}`}
      aria-describedby={`desc-${tutorial.id}`}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onClick();
        }
      }}
    >
      <div className="flex items-center gap-4 mb-4">
        <div className={`p-3 rounded-full ${iconStyles.bg}`}>
          <CardIcon size={40} className={iconStyles.color} />
        </div>
        <h3 className="text-2xl font-bold leading-tight">
          {tutorial.title}
        </h3>
      </div>
      
      <p id={`desc-${tutorial.id}`} className="text-lg mb-6 flex-grow leading-relaxed opacity-90">
        {tutorial.shortDescription}
      </p>

      <div className="mt-auto">
        <span className={`w-full py-4 px-6 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-colors ${getButtonStyle()}`}>
          Ler Dicas
          <ArrowRight size={24} />
        </span>
      </div>
    </article>
  );
};

export default TutorialCard;