import React from 'react';
import TutorialCard from './TutorialCard';
import { TUTORIALS } from '../constants';
import { Tutorial, ThemeMode } from '../types';
import { FileText } from 'lucide-react';

interface TutorialListProps {
  theme: ThemeMode;
  onSelectTutorial: (t: Tutorial) => void;
}

const TutorialList: React.FC<TutorialListProps> = ({ theme, onSelectTutorial }) => {

  // Function to generate a print-friendly view (simulating PDF generation for extension projects)
  const generatePDF = (tutorial: Tutorial) => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>InfoSolidária - ${tutorial.title}</title>
            <style>
              body { font-family: sans-serif; padding: 40px; color: #000; line-height: 1.6; }
              header { border-bottom: 2px solid #000; padding-bottom: 20px; margin-bottom: 30px; display: flex; align-items: center; justify-content: space-between; }
              h1 { font-size: 28px; margin: 0; color: #0f766e; } /* Teal-700 */
              .logo { font-size: 14px; color: #666; }
              .content { font-size: 18px; margin-bottom: 30px; }
              .tips-box { background: #f0fdfa; border: 2px solid #0f766e; padding: 20px; border-radius: 8px; }
              h2 { font-size: 22px; margin-top: 0; }
              ul { padding-left: 20px; }
              li { margin-bottom: 10px; font-size: 16px; }
              .footer { margin-top: 50px; font-size: 12px; text-align: center; color: #888; border-top: 1px solid #ddd; padding-top: 20px; }
              @media print {
                body { padding: 0; }
                .no-print { display: none; }
              }
            </style>
          </head>
          <body>
            <header>
              <div>
                <h1>${tutorial.title}</h1>
                <div class="logo">Projeto InfoSolidária - Segurança Digital</div>
              </div>
            </header>
            
            <div class="content">
              <p><strong>Resumo:</strong> ${tutorial.shortDescription}</p>
              <p>${tutorial.fullContent}</p>
            </div>

            <div class="tips-box">
              <h2>O que você deve fazer:</h2>
              <ul>
                ${tutorial.tips.map(tip => `<li>${tip}</li>`).join('')}
              </ul>
            </div>

            <div class="footer">
              <p>Material de apoio educativo - Projeto de Extensão Universitária InfoSolidária.</p>
              <p>Gerado em: ${new Date().toLocaleDateString()}</p>
            </div>

            <script>
              window.onload = function() { window.print(); }
            </script>
          </body>
        </html>
      `);
      printWindow.document.close();
    } else {
      alert("Por favor, permita pop-ups para gerar o PDF.");
    }
  };

  const getHeadingColor = () => {
    switch(theme) {
      case 'high-contrast': return 'text-yellow-400';
      case 'dark': return 'text-teal-400';
      default: return 'text-teal-900';
    }
  };

  const getButtonStyles = () => {
    switch(theme) {
      case 'high-contrast': return 'border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black focus:ring-yellow-400 ring-offset-black';
      case 'dark': return 'border-teal-700 text-teal-300 bg-gray-800 hover:bg-teal-900 hover:border-teal-500 focus:ring-teal-400';
      default: return 'border-teal-200 text-teal-700 bg-teal-50 hover:bg-teal-100 hover:border-teal-300 focus:ring-orange-400';
    }
  };

  return (
    // ID added for Skip Link navigation
    <main id="main-content" className="max-w-6xl mx-auto px-4 py-12 focus:outline-none" tabIndex={-1}>
      <h2 className={`text-3xl font-bold mb-8 text-center animate-fade-in ${getHeadingColor()}`}>
        Escolha um tema para aprender
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {TUTORIALS.map((tutorial, index) => (
          <div 
            key={tutorial.id} 
            className="flex flex-col h-full animate-slide-up"
            style={{ animationDelay: `${index * 100}ms` }} 
          >
            {/* Wrapper for Card to ensure height consistency */}
            <div className="flex-grow">
              <TutorialCard 
                tutorial={tutorial} 
                theme={theme}
                onClick={() => onSelectTutorial(tutorial)}
              />
            </div>

            {/* Reuse Material Button (PDF/Print) */}
            <button
              onClick={() => generatePDF(tutorial)}
              className={`mt-3 w-full py-2 px-4 rounded-lg flex items-center justify-center gap-2 text-sm font-bold border-2 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 ${getButtonStyles()}`}
              aria-label={`Imprimir material sobre ${tutorial.title}`}
              title="Gerar PDF para impressão"
            >
              <FileText size={18} />
              Reutilizar Conteúdo (Versão PDF Simples)
            </button>
          </div>
        ))}
      </div>
    </main>
  );
};

export default TutorialList;