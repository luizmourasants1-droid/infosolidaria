import React from 'react';
import { ThemeMode } from '../types';

interface FooterProps {
  theme: ThemeMode;
}

const Footer: React.FC<FooterProps> = ({ theme }) => {
  const getStyles = () => {
    switch(theme) {
      case 'high-contrast': return 'bg-gray-900 border-t-2 border-yellow-400 text-yellow-400';
      case 'dark': return 'bg-gray-900 border-t border-gray-800 text-gray-400';
      default: return 'bg-slate-100 border-t border-teal-200 text-slate-600';
    }
  };

  return (
    <footer className={`py-8 px-4 mt-auto text-center transition-colors duration-300 ${getStyles()}`}>
      <p className="text-lg font-medium mb-2">
        &copy; {new Date().getFullYear()} <strong>InfoSolidária</strong>
      </p>
      <p className="text-base opacity-90">
        Projeto de Extensão Universitária • Desenvolvido com foco em Acessibilidade e Inclusão Digital.
      </p>
    </footer>
  );
};

export default Footer;