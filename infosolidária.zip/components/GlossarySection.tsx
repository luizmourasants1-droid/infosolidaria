import React from 'react';
import { BookOpen, ShieldQuestion } from 'lucide-react';
import { ThemeMode } from '../types';

interface GlossarySectionProps {
  theme: ThemeMode;
}

const GLOSSARY_TERMS = [
  {
    term: 'Phishing (Pescaria Digital)',
    definition: 'É quando bandidos enviam mensagens falsas (e-mail, SMS) fingindo ser bancos ou lojas para roubar sua senha.'
  },
  {
    term: 'Malware (Vírus)',
    definition: 'Qualquer programa ruim que entra no computador ou celular para estragar arquivos ou espionar você.'
  },
  {
    term: 'HTTPS (Cadeado)',
    definition: 'O "S" significa Segurança. Indica que o site protege seus dados. Procure sempre o cadeado 🔒 no navegador.'
  },
  {
    term: '2FA (Dupla Proteção)',
    definition: 'Autenticação em Dois Fatores. É como ter duas fechaduras na porta: precisa da senha E de um código extra.'
  },
  {
    term: 'Firewall (Porteiro)',
    definition: 'Uma barreira de segurança que controla quem entra e quem sai da sua internet, bloqueando invasores.'
  },
  {
    term: 'Spam (Lixo)',
    definition: 'Mensagens indesejadas, geralmente propagandas ou golpes, enviadas para muitas pessoas ao mesmo tempo.'
  }
];

const GlossarySection: React.FC<GlossarySectionProps> = ({ theme }) => {
  const getContainerBg = () => {
    switch(theme) {
      case 'high-contrast': return 'bg-black border-t-4 border-yellow-400';
      case 'dark': return 'bg-gray-900 border-t border-gray-800';
      default: return 'bg-teal-50 border-t-4 border-teal-200';
    }
  };

  const getCardBg = () => {
    switch(theme) {
      case 'high-contrast': return 'bg-gray-900 border-2 border-yellow-400';
      case 'dark': return 'bg-gray-800 border-l-4 border-teal-500 shadow-md';
      default: return 'bg-white border-l-4 border-orange-400 shadow-sm';
    }
  };

  const titleColor = theme === 'high-contrast' ? 'text-yellow-400' : (theme === 'dark' ? 'text-teal-400' : 'text-teal-800');
  const termColor = theme === 'high-contrast' ? 'text-yellow-400' : (theme === 'dark' ? 'text-gray-100' : 'text-teal-700');
  const defColor = theme === 'high-contrast' ? 'text-white' : (theme === 'dark' ? 'text-gray-300' : 'text-slate-700');
  
  const iconColor = theme === 'high-contrast' ? 'text-yellow-400' : (theme === 'dark' ? 'text-teal-400' : 'text-orange-500');

  return (
    <section className={`py-12 px-4 mt-8 ${getContainerBg()}`}>
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-3 mb-8 justify-center">
          <BookOpen size={40} className={theme === 'high-contrast' ? 'text-yellow-400' : (theme === 'dark' ? 'text-teal-500' : 'text-teal-600')} />
          <h2 className={`text-3xl md:text-4xl font-extrabold text-center ${titleColor}`}>
            O Dicionário da Segurança
          </h2>
        </div>
        
        <p className={`text-center text-xl mb-10 max-w-3xl mx-auto ${defColor}`}>
          Não entendeu alguma palavra difícil? Aqui explicamos o "internetês" de forma simples.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {GLOSSARY_TERMS.map((item, index) => (
            <div 
              key={index} 
              className={`p-6 rounded-lg transition-transform hover:-translate-y-1 ${getCardBg()}`}
            >
              <div className="flex items-start gap-3 mb-3">
                <ShieldQuestion size={24} className={`flex-shrink-0 mt-1 ${iconColor}`} />
                <h3 className={`text-xl font-bold ${termColor}`}>
                  {item.term}
                </h3>
              </div>
              <p className={`text-lg leading-relaxed ${defColor}`}>
                {item.definition}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default GlossarySection;