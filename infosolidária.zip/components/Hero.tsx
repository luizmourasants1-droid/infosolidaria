import React from 'react';
import { ThemeMode } from '../types';

interface HeroProps {
  theme: ThemeMode;
}

const Hero: React.FC<HeroProps> = ({ theme }) => {
  
  const getContainerStyles = () => {
    switch (theme) {
      case 'high-contrast': return 'bg-black text-yellow-400 border-b-4 border-yellow-400';
      case 'dark': return 'bg-gray-900 text-gray-100 border-b border-gray-800';
      default: return 'bg-teal-50 text-slate-800 border-b-4 border-teal-200';
    }
  };

  const getHighlightStyles = () => {
    switch (theme) {
      case 'high-contrast': return 'bg-yellow-400 text-black';
      case 'dark': return 'bg-teal-900/50 text-teal-300 border border-teal-700';
      default: return 'bg-teal-100 text-teal-900 border border-teal-200';
    }
  };

  return (
    <section className={`py-12 px-4 transition-colors duration-300 ${getContainerStyles()}`}>
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-4xl md:text-5xl font-bold mb-6 animate-slide-up">
          Proteja-se na Internet
        </h2>
        <p className="text-xl md:text-2xl leading-relaxed mb-8 max-w-2xl mx-auto animate-slide-up delay-100">
          A internet é maravilhosa, mas precisamos ter cuidado. 
          O <strong>InfoSolidária</strong> é um projeto gratuito para ensinar você a identificar 
          golpes, criar senhas seguras e navegar com tranquilidade.
        </p>
        <div className={`inline-block px-6 py-3 rounded-lg font-bold text-lg animate-slide-up delay-200 ${getHighlightStyles()}`}>
          Navegue pelos cartões abaixo para aprender 👇
        </div>
      </div>
    </section>
  );
};

export default Hero;