import React, { useEffect, useRef, useState } from 'react';
import { X, CheckCircle2, HelpCircle, AlertCircle, ThumbsUp, ThumbsDown, ArrowRight, MessageSquare, ExternalLink } from 'lucide-react';
import { Tutorial, ThemeMode } from '../types';
import SlideShow from './SlideShow';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  tutorial: Tutorial | null;
  theme: ThemeMode;
}

// Helper function to generate accessible UI sounds using Web Audio API
const playFeedbackSound = (type: 'success' | 'error' | 'click') => {
  try {
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;

    const ctx = new AudioContext();
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);

    const now = ctx.currentTime;

    if (type === 'success') {
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(523.25, now);
      oscillator.frequency.exponentialRampToValueAtTime(1046.5, now + 0.1);
      gainNode.gain.setValueAtTime(0.2, now);
      gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
      oscillator.start(now);
      oscillator.stop(now + 0.5);
    } else if (type === 'error') {
      oscillator.type = 'triangle';
      oscillator.frequency.setValueAtTime(150, now);
      oscillator.frequency.linearRampToValueAtTime(100, now + 0.2);
      gainNode.gain.setValueAtTime(0.2, now);
      gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
      oscillator.start(now);
      oscillator.stop(now + 0.3);
    } else if (type === 'click') {
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(800, now);
      gainNode.gain.setValueAtTime(0.1, now);
      gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
      oscillator.start(now);
      oscillator.stop(now + 0.1);
    }
  } catch (error) {
    console.error("Audio feedback failed:", error);
  }
};

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, tutorial, theme }) => {
  const modalRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const [quizState, setQuizState] = useState<'unanswered' | 'correct' | 'incorrect'>('unanswered');
  const [feedbackStatus, setFeedbackStatus] = useState<'idle' | 'voted'>('idle');

  // Reset states when modal opens/closes or tutorial changes
  useEffect(() => {
    if (isOpen) {
      setQuizState('unanswered');
      setFeedbackStatus('idle');
      // Focus management: set focus to close button when opened
      setTimeout(() => closeButtonRef.current?.focus(), 100);
    }
  }, [isOpen, tutorial]);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const handleQuizAnswer = (index: number) => {
    if (!tutorial || !tutorial.quiz) return;
    
    if (index === tutorial.quiz.correctIndex) {
      setQuizState('correct');
      playFeedbackSound('success');
    } else {
      setQuizState('incorrect');
      playFeedbackSound('error');
    }
  };

  const handleFeedback = (type: 'up' | 'down') => {
    playFeedbackSound('click');
    setFeedbackStatus('voted');
    console.log(`User voted thumbs ${type} for tutorial ${tutorial?.id}`);
  };

  const handleNextStep = (step: { action: string, url?: string }) => {
    playFeedbackSound('click');
    if (!step.url) {
      alert(`Simulação de ação: ${step.action}`);
    }
  };

  if (!isOpen || !tutorial) return null;

  // --- THEME STYLING LOGIC ---

  const getOverlayStyle = () => {
    switch(theme) {
      case 'high-contrast': return 'bg-white/20';
      case 'dark': return 'bg-black/80';
      default: return 'bg-black/60';
    }
  };

  const getContentStyle = () => {
    switch(theme) {
      case 'high-contrast': return 'bg-black border-4 border-yellow-400 text-yellow-400';
      case 'dark': return 'bg-gray-800 text-gray-100 border border-gray-700';
      default: return 'bg-white text-slate-800';
    }
  };

  const getCloseBtnStyle = () => {
    switch(theme) {
      case 'high-contrast': return 'bg-yellow-400 text-black hover:bg-yellow-300 focus:ring-white ring-offset-black';
      case 'dark': return 'bg-gray-700 text-gray-200 hover:bg-gray-600 focus:ring-teal-400';
      default: return 'bg-slate-200 text-slate-700 hover:bg-slate-300 focus:ring-orange-400';
    }
  };

  // Text Colors
  const headingColor = theme === 'high-contrast' ? 'text-yellow-400' : (theme === 'dark' ? 'text-teal-400' : 'text-teal-800');
  const subHeadingColor = theme === 'high-contrast' ? 'text-yellow-200' : (theme === 'dark' ? 'text-gray-300' : 'text-slate-600');
  
  // Elements
  const getTipBg = () => {
    switch(theme) {
      case 'high-contrast': return 'bg-gray-900 border border-yellow-400';
      case 'dark': return 'bg-gray-900 border-l-4 border-teal-500';
      default: return 'bg-teal-50 border-l-4 border-teal-500';
    }
  };

  const sectionDivider = theme === 'high-contrast' ? 'border-yellow-400' : (theme === 'dark' ? 'border-gray-700' : 'border-slate-200');

  const getQuizSectionStyle = () => {
    switch(theme) {
      case 'high-contrast': return 'bg-gray-900 border-2 border-yellow-400';
      case 'dark': return 'bg-gray-900 border border-gray-700';
      default: return 'bg-slate-50 border border-slate-200';
    }
  };

  const getQuizOptionStyle = () => {
    switch(theme) {
      case 'high-contrast': return 'bg-black border-2 border-yellow-400 text-yellow-400 hover:bg-gray-800 focus:ring-yellow-400';
      case 'dark': return 'bg-gray-800 border-2 border-gray-600 text-gray-200 hover:bg-gray-700 hover:border-teal-500 focus:ring-teal-400';
      default: return 'bg-white border-2 border-teal-200 text-slate-700 hover:bg-teal-50 hover:border-teal-400 focus:ring-orange-400';
    }
  };

  const getNextStepBtnStyle = () => {
    switch(theme) {
      case 'high-contrast': return 'bg-yellow-400 text-black hover:bg-white border-2 border-yellow-400';
      case 'dark': return 'bg-teal-600 text-white hover:bg-teal-500 shadow-md';
      default: return 'bg-orange-500 text-white hover:bg-orange-600 shadow-md';
    }
  };

  const getFeedbackBtnStyle = () => {
    switch(theme) {
      case 'high-contrast': return 'border-2 border-yellow-400 hover:bg-yellow-400 hover:text-black';
      case 'dark': return 'border-2 border-gray-600 hover:border-teal-500 hover:bg-gray-700 hover:text-teal-400';
      default: return 'border-2 border-slate-300 hover:border-teal-500 hover:bg-teal-50 hover:text-teal-600';
    }
  };

  const feedbackContainerBg = theme === 'high-contrast' ? 'bg-gray-900 border-yellow-400' : (theme === 'dark' ? 'bg-gray-900 border-gray-700' : 'bg-slate-50 border-slate-200');

  return (
    <div 
      className={`fixed inset-0 z-[100] flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in ${getOverlayStyle()}`}
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div 
        ref={modalRef}
        className={`relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl shadow-2xl animate-pop-in ${getContentStyle()}`}
      >
        {/* Close Button */}
        <button
          ref={closeButtonRef}
          onClick={onClose}
          className={`absolute top-4 right-4 p-2 z-10 rounded-full transition-colors focus:outline-none focus:ring-4 focus:ring-offset-2 ${getCloseBtnStyle()}`}
          aria-label="Fechar janela"
        >
          <X size={32} />
        </button>

        <div className="p-6 md:p-8">
          {/* Header */}
          <header className="mb-6 pr-12">
            <div className="flex items-center gap-3 mb-2">
              <tutorial.icon size={32} className={headingColor} />
              <span className={`text-sm font-bold uppercase tracking-wide ${headingColor}`}>
                Tutorial de Segurança
              </span>
            </div>
            <h2 id="modal-title" className={`text-3xl md:text-4xl font-extrabold ${headingColor}`}>
              {tutorial.title}
            </h2>
          </header>

          <div className="prose max-w-none">
            
            {/* Visual Slideshow */}
            {tutorial.slides && tutorial.slides.length > 0 && (
              <SlideShow slides={tutorial.slides} theme={theme} />
            )}

            {/* Main Content */}
            <p className="text-xl md:text-2xl font-medium mb-6 leading-relaxed">
              {tutorial.fullContent}
            </p>

            {/* Practical Tips */}
            <h3 className={`text-2xl font-bold mb-4 ${headingColor}`}>
              O que você deve fazer:
            </h3>
            <ul className="space-y-4 mb-8">
              {tutorial.tips.map((tip, index) => (
                <li 
                  key={index} 
                  className={`p-4 rounded-lg flex items-start gap-3 ${getTipBg()}`}
                >
                  <CheckCircle2 className={`flex-shrink-0 mt-1 ${theme === 'high-contrast' ? 'text-yellow-400' : 'text-teal-600'}`} size={24} />
                  <span className="text-lg md:text-xl font-medium">{tip}</span>
                </li>
              ))}
            </ul>

            {/* Quiz Section */}
            {tutorial.quiz && (
              <div className={`p-6 rounded-xl mt-8 ${getQuizSectionStyle()}`}>
                <div className="flex items-center gap-2 mb-4">
                  <HelpCircle size={28} className={theme === 'high-contrast' ? 'text-yellow-400' : (theme === 'dark' ? 'text-teal-400' : 'text-teal-600')} />
                  <h3 className={`text-2xl font-bold ${theme === 'high-contrast' ? 'text-yellow-400' : (theme === 'dark' ? 'text-gray-100' : 'text-slate-800')}`}>
                    Quiz Rápido
                  </h3>
                </div>
                
                <p className="text-lg mb-4 font-semibold">
                  {tutorial.quiz.question}
                </p>

                <div aria-live="polite" aria-atomic="true">
                  {quizState === 'unanswered' ? (
                    <div className="space-y-3">
                      {tutorial.quiz.options.map((option, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleQuizAnswer(idx)}
                          className={`w-full text-left p-4 rounded-lg text-lg font-medium transition-all focus:outline-none focus:ring-4 ${getQuizOptionStyle()}`}
                        >
                          {option}
                        </button>
                      ))}
                    </div>
                  ) : (
                    <div 
                      className={`p-4 rounded-lg flex flex-col gap-2 animate-in fade-in zoom-in duration-300 ${
                        quizState === 'correct' 
                          ? (theme === 'high-contrast' ? 'bg-black border-2 border-green-400 text-green-400' : (theme === 'dark' ? 'bg-green-900/30 border border-green-500 text-green-300' : 'bg-green-50 border border-green-200 text-green-800'))
                          : (theme === 'high-contrast' ? 'bg-black border-2 border-red-500 text-red-500' : (theme === 'dark' ? 'bg-red-900/30 border border-red-500 text-red-300' : 'bg-red-50 border border-red-200 text-red-800'))
                      }`}
                      role="alert"
                    >
                      <div className="flex items-center gap-3 font-bold text-xl">
                        {quizState === 'correct' ? (
                          <>
                            <ThumbsUp size={28} />
                            <span>Muito bem! Resposta Correta.</span>
                          </>
                        ) : (
                          <>
                            <AlertCircle size={28} />
                            <span>Ops, não é bem isso.</span>
                          </>
                        )}
                      </div>
                      <p className="text-lg mt-2">{tutorial.quiz.explanation}</p>
                      <button 
                        onClick={() => setQuizState('unanswered')}
                        className={`mt-4 self-start px-6 py-2 rounded-lg font-bold focus:outline-none focus:ring-4 focus:ring-offset-2 ${
                           theme === 'high-contrast' 
                           ? 'bg-yellow-400 text-black hover:bg-yellow-300 focus:ring-white ring-offset-black' 
                           : (theme === 'dark' 
                                ? 'bg-gray-700 text-gray-100 border-2 border-gray-600 hover:bg-gray-600 focus:ring-teal-400'
                                : 'bg-white text-slate-800 border-2 border-slate-300 hover:bg-slate-50 focus:ring-orange-400')
                        }`}
                      >
                        Tentar Novamente
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* NEXT STEPS SECTION (Links) */}
            {tutorial.nextSteps && tutorial.nextSteps.length > 0 && (
              <div className={`mt-10 pt-8 border-t-2 ${sectionDivider}`}>
                <h3 className={`text-2xl font-bold mb-6 flex items-center gap-2 ${headingColor}`}>
                  <ArrowRight size={28} />
                  Meu Próximo Passo
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {tutorial.nextSteps.map((step, idx) => {
                    const StepTag = step.url ? 'a' : 'button';
                    const externalProps = step.url ? { target: "_blank", rel: "noopener noreferrer" } : {};
                    
                    return (
                      <StepTag
                        key={idx}
                        href={step.url}
                        onClick={(e) => {
                          if (!step.url) { 
                             e.preventDefault();
                             handleNextStep(step);
                          } else {
                             playFeedbackSound('click');
                          }
                        }}
                        className={`p-4 rounded-xl text-left flex items-start gap-4 transition-transform active:scale-95 focus:outline-none focus:ring-4 focus:ring-offset-2 ${getNextStepBtnStyle()} no-underline`}
                        title={step.label}
                        {...externalProps}
                      >
                        <div className={`p-2 rounded-lg flex-shrink-0 ${theme === 'high-contrast' ? 'bg-black text-yellow-400' : 'bg-white/20 text-white'}`}>
                          <step.icon size={24} />
                        </div>
                        <div className="flex-1">
                          <div className="font-bold text-lg mb-1 flex items-center gap-2">
                            {step.label}
                            {step.url && <ExternalLink size={16} className="opacity-70" />}
                          </div>
                          <div className={`text-sm ${theme === 'high-contrast' ? 'text-black/80' : 'text-white/90'}`}>
                            {step.action}
                          </div>
                        </div>
                      </StepTag>
                    );
                  })}
                </div>
              </div>
            )}

          </div>
        </div>

        {/* FEEDBACK SECTION */}
        <div className={`p-6 md:p-8 mt-auto border-t text-center ${feedbackContainerBg}`}>
          {feedbackStatus === 'idle' ? (
            <div className="animate-fade-in">
              <p className={`text-lg font-bold mb-4 flex items-center justify-center gap-2 ${subHeadingColor}`}>
                <MessageSquare size={20} />
                Este tutorial ajudou você?
              </p>
              <div className="flex justify-center gap-4">
                <button
                  onClick={() => handleFeedback('up')}
                  className={`flex items-center gap-2 px-6 py-3 rounded-full font-bold transition-colors focus:outline-none focus:ring-4 ${getFeedbackBtnStyle()}`}
                  aria-label="Sim, ajudou"
                >
                  <ThumbsUp size={24} />
                  Sim
                </button>
                <button
                  onClick={() => handleFeedback('down')}
                  className={`flex items-center gap-2 px-6 py-3 rounded-full font-bold transition-colors focus:outline-none focus:ring-4 ${getFeedbackBtnStyle()}`}
                  aria-label="Não ajudou muito"
                >
                  <ThumbsDown size={24} />
                  Não
                </button>
              </div>
            </div>
          ) : (
            <div className="animate-fade-in p-4 rounded-lg bg-green-100 border border-green-300 text-green-800 inline-block">
              <p className="font-bold text-xl flex items-center gap-2">
                <CheckCircle2 size={24} />
                Obrigado pela sua opinião!
              </p>
              <p className="text-sm mt-1">Sua avaliação ajuda a melhorar o InfoSolidária.</p>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};

export default Modal;